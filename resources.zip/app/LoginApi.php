<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LoginApi extends Model
{
    //
}
