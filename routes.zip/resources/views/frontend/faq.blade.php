@extends('layout.master')  
@section('title')
FAQ || Wales Miner
@endsection

@section('content')

<!-- Start main-content -->
  <div class="main-content">
    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-white-8" data-bg-img="assets/images/bg/bg6.jpg">
      <div class="container pt-60 pb-60">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center">
              <h2 class="text-theme-colored2 font-36">FREQUENTLY ASKED QUESTION</h2>
              <ol class="breadcrumb text-center text-black mt-10">
                <li><a href="#">Home</a></li>
                <li class="active text-theme-colored">FAQ</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section> 

    <section class="position-inherit">
      <div class="container">
        <div class="row">
          <div class="col-md-3 scrolltofixed-container">
            <div class="list-group scrolltofixed z-index-0">
              <a href="#" class="list-group-item smooth-scroll-to-target">What is Wales Miner?</a>

              <a href="#" class="list-group-item smooth-scroll-to-target">Who Manages the Investment Portfolio?</a>

              <a href="#" class="list-group-item smooth-scroll-to-target">How can i Invest with Wales Miner?</a>

              <a href="#" class="list-group-item smooth-scroll-to-target">How do i Open My Forexop Account?</a>

              <a href="#" class="list-group-item smooth-scroll-to-target">How Can I Change Email Or Password?</a>

              <a href="#" class="list-group-item smooth-scroll-to-target">What if I cant login to my account because i forgot my password?</a>

              <a href="#" class="list-group-item smooth-scroll-to-target">I cant login to my account, What could cause the problem?</a>

              <a href="#" class="list-group-item smooth-scroll-to-target">How many account can i create for one computer?</a>

              <a href="#" class="list-group-item smooth-scroll-to-target">Which E-currency do you accept?</a>

              <a href="#" class="list-group-item smooth-scroll-to-target">How long does it take for my deposit to be added to my account?</a>

              <a href="#" class="list-group-item smooth-scroll-to-target">Can i do a direct deposit from my account balance?</a>

              <a href="#" class="list-group-item smooth-scroll-to-target">Can i make additional deposit to my account balance once it has been opened?</a>

              <a href="#" class="list-group-item smooth-scroll-to-target">How Can I invest?</a>

              <a href="#" class="list-group-item smooth-scroll-to-target">After i make a withdrawal request, whe will the fund be available to E-currency account?</a>

              <a href="#" class="list-group-item smooth-scroll-to-target">How Can I withdraw funds?</a>

              <a href="#" class="list-group-item smooth-scroll-to-target">What is the referral commission wales miner offers to its members?</a>

              <a href="#" class="list-group-item smooth-scroll-to-target">Will i receive referral commission, if my referral deposit fromm his account balance?</a>
            </div>
          </div>
          <div class="col-md-9">
              <h2 class="">Frequently Asked <span class="text-theme-colored2">Questions</span></h2>
              <div class="diamond-line-left-theme-colored2"></div>
              <div class="panel-group accordion-stylished-left-border accordion-icon-filled accordion-no-border accordion-icon-left accordion-icon-filled-theme-colored2 accordion-large" id="accordion6" role="tablist" aria-multiselectable="true">
                <div class="panel panel-default">
                  <div class="panel-heading" role="tab" id="headin1">
                    <h6 class="panel-title">
                      <a role="button" data-toggle="collapse" data-parent="#accordion6" href="#collaps1" aria-expanded="true" aria-controls="collaps1">
                        What is Wales Miner?
                      </a>
                    </h6>
                  </div>
                  <div id="collaps1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headin1">
                    <div class="panel-body">
                      It is an online investment platform authorized and regulated by the United Kingdom Company House Authority. This information can be verified on the Company House website.
                    </div>
                  </div>
                </div>
                <div class="panel panel-default">
                  <div class="panel-heading" role="tab" id="heading2">
                    <h6 class="panel-title">
                      <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion6" href="#collapse2" aria-expanded="false" aria-controls="collapse2">
                        Who Manages the Investment Portfolio?
                      </a>
                    </h6>
                  </div>
                  <div id="collapse2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading2">
                    <div class="panel-body">
                      The investment portfolio is managed by our team of financial specialists with strong command in finance allows for effective analysis of the market and financial situation. The Company employs experts on the full-time basis who have been working on the currency exchange and forex markets for more than 7 years on average. Our financial team also includes specialists who are experts in evaluating new private businesses called start-ups which have most chances to grow into large-scale and highly profitable enterprises.
                    </div>
                  </div>
                </div>
                <div class="panel panel-default">
                  <div class="panel-heading" role="tab" id="heading3">
                    <h6 class="panel-title">
                      <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion6" href="#collapse3" aria-expanded="false" aria-controls="collapse3">
                        How can i Invest with Wales Miner?
                      </a>
                    </h6>
                  </div>
                  <div id="collapse3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading3">
                    <div class="panel-body">
                      To make an investment you must first become a member of our program. Once you are signed up, you can make your first deposit. All deposits must be made through the Members Area. You can login using the member username and password you receive when you signup.
                    </div>
                  </div>
                </div>
                <div class="panel panel-default">
                  <div class="panel-heading" role="tab" id="heading4">
                    <h6 class="panel-title">
                      <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion6" href="#collapse4" aria-expanded="false" aria-controls="collapse4">
                        How do i Open My Forexop Account?
                      </a>
                    </h6>
                  </div>
                  <div id="collapse4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading4">
                    <div class="panel-body">
                      It's quite easy and convenient. Click on "Register now" button, fill in the registration form and then press "Register".
                    </div>
                  </div>
                </div>
                <div class="panel panel-default">
                  <div class="panel-heading" role="tab" id="heading5">
                    <h6 class="panel-title">
                      <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion6" href="#collapse5" aria-expanded="false" aria-controls="collapse5">
                        How Can I Change Email Or Password?
                      </a>
                    </h6>
                  </div>
                  <div id="collapse5" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading5">
                    <div class="panel-body">
                      Log into your forexop account and click on the "Edit Account". You can change your e-mail address and password there.
                    </div>
                  </div>
                </div>
                <div class="panel panel-default">
                  <div class="panel-heading" role="tab" id="heading6">
                    <h6 class="panel-title">
                      <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion6" href="#collapse6" aria-expanded="false" aria-controls="collapse6">
                        What if I cant login to my account because i forgot my password?
                      </a>
                    </h6>
                  </div>
                  <div id="collapse6" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading6">
                    <div class="panel-body">
                      Click forgot password link, type your username or e-mail and you'll receive your account information.
                    </div>
                  </div>
                </div>
                <div class="panel panel-default">
                  <div class="panel-heading" role="tab" id="heading7">
                    <h6 class="panel-title">
                      <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion6" href="#collapse7" aria-expanded="false" aria-controls="collapse7">
                        I cant login to my account, What could cause the problem?
                      </a>
                    </h6>
                  </div>
                  <div id="collapse7" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading7">
                    <div class="panel-body">
                      Sometimes problems of this kind are caused by errors of your web browser. There is no reason to worry, you just need to wait a few minutes and then try to log in again. First of all you need to clean the cache of your web browser. If the problem persists, please contact us.
                    </div>
                  </div>
                </div>
                <div class="panel panel-default">
                  <div class="panel-heading" role="tab" id="heading8">
                    <h6 class="panel-title">
                      <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion6" href="#collapse8" aria-expanded="false" aria-controls="collapse8">
                        How many account can i create for one computer?
                      </a>
                    </h6>
                  </div>
                  <div id="collapse8" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading8">
                    <div class="panel-body">
                      Only one account is allowed from one computer or one IP address. Failing to do so, will result in immediate ban of your account and your funds will be seized. If you want to create another account, CONTACT US.
                    </div>
                  </div>
                </div>
                <div class="panel panel-default">
                  <div class="panel-heading" role="tab" id="heading9">
                    <h6 class="panel-title">
                      <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion6" href="#collapse9" aria-expanded="false" aria-controls="collapse9">
                        Which E-currency do you accept?
                      </a>
                    </h6>
                  </div>
                  <div id="collapse9" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading9">
                    <div class="panel-body">
                      We accept PerfectMoney, Payeer & BitCoin.
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
      </div>
    </section>

  </div>
  <!-- end main-content -->


@endsection